//
//  main.m
//  SignificantDates
//
//  Created by Chris Wagner on 5/14/12.
//

#import <UIKit/UIKit.h>

#import "SDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SDAppDelegate class]));
    }
}
