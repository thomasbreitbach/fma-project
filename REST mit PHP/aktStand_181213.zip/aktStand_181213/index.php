<?php
/**
 * Step 1: Require the Slim Framework
 *
 * If you are not using Composer, you need to require the
 * Slim Framework and register its PSR-0 autoloader.
 *
 * If you are using Composer, you can skip this step.
 */
require 'Slim/Slim.php';
require 'RedBean/rb.php';

\Slim\Slim::registerAutoloader();

// set up database connection
R::setup('mysql:host=localhost;dbname=u12715_fma','u12715_fma','fma2013');
R::freeze(true);

/**
 * Step 2: Instantiate a Slim application
 *
 * This example instantiates a Slim application using
 * its default settings. However, you will usually configure
 * your Slim application now by passing an associative array
 * of setting names and values into the application constructor.
 */
$app = new \Slim\Slim();



/**
*
* TAGEBUCH
*
*/
$app->get('/books/', function () use ($app) {
    // query database for all articles
    $books = R::getAll('select * from books');

    // send response header for JSON content type
    $app->response()->header('Content-Type', 'application/json');

    // return JSON-encoded response body with query results
    echo json_encode($books);
});

$app->get('/books/:id/', function ($id) use ($app) {
    try {
        // query database for all articles
        $book = R::findOne('books', 'bID = ?', array($id));

        if($book){
            $app->response()->header('Content-Type', 'application/json');
            echo json_encode(R::exportAll($book));
        }else{
            throw new ResourceNotFoundException();
        }
    }catch (ResourceNotFoundException $e) {
        // return 404 server error
        $app->response()->status(404);
    } catch (Exception $e) {
        $app->response()->status(400);
        $app->response()->header('X-Status-Reason', $e->getMessage());
    }
});



$app->get('/books/:id/entries/', function ($id) use ($app) {
    $app->response->setStatus(202);
    $app->response->setBody($id);
});



/**
 * Step 4: Run the Slim application
 *
 * This method should be called last. This executes the Slim application
 * and returns the HTTP response to the HTTP client.
 */
$app->run();
?>
